/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.consultas_producto;
import modelo.producto;
import vista.frmProducto;

/**
 *
 * @author Gustavo
 */
public class ctrlproducto implements ActionListener {
    
    private producto mod;
    private consultas_producto modC;
    private frmProducto frm;
    
    public ctrlproducto (producto mod, consultas_producto modC, frmProducto frm) {
        this.mod = mod;
        this.modC = modC;
        this.frm = frm;
        this.frm.btnguardar.addActionListener(this);
        this.frm.btnmodificar.addActionListener(this);
        this.frm.btneliminar.addActionListener(this);
        this.frm.btnlimpiar.addActionListener(this);
        this.frm.btnbuscar.addActionListener(this);
    }
    
    public void iniciar() {
        frm.setTitle("productos");
        frm.setLocationRelativeTo(null);
        frm.txtid.setVisible(false);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        
        if (e.getSource() == frm.btnguardar ){
            mod.setCodigo(frm.txtcodigo.getText());
            mod.setNombre(frm.txtnombre.getText());
            mod.setPrecio( Double.parseDouble( frm.txtprecio.getText()));
            mod.setCantidad(Integer.parseInt(frm.txtcantidad.getText()));
            
            if (modC.registrar(mod)){
                JOptionPane.showMessageDialog(null, "Registro Guardado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al guardar");
                limpiar();
            }
            
        }
        
        if (e.getSource() == frm.btnmodificar ){
            mod.setId(Integer.parseInt(frm.txtid.getText()));
            mod.setCodigo(frm.txtcodigo.getText());
            mod.setNombre(frm.txtnombre.getText());
            mod.setPrecio( Double.parseDouble( frm.txtprecio.getText()));
            mod.setCantidad(Integer.parseInt(frm.txtcantidad.getText()));
            
            if (modC.modificar(mod)){
                JOptionPane.showMessageDialog(null, "Modificado Correctamente");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar");
                limpiar();
            }
            
        }
        
        if (e.getSource() == frm.btneliminar ){
            mod.setId(Integer.parseInt(frm.txtid.getText()));
           
            
            if (modC.eliminar(mod)){
                JOptionPane.showMessageDialog(null, "Registro Eliminado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar");
                limpiar();
            }
            
        }
        
        if (e.getSource() == frm.btnbuscar ){
            mod.setCodigo(frm.txtcodigo.getText());
           
            
            if (modC.buscar(mod)){
                
                frm.txtid.setText(String.valueOf(mod.getId()));
                frm.txtcodigo.setText(mod.getCodigo());
                frm.txtnombre.setText(mod.getNombre());
                frm.txtprecio.setText(String.valueOf(mod.getPrecio()));
                frm.txtcantidad.setText(String.valueOf(mod.getCantidad()));
                
            } else {
                JOptionPane.showMessageDialog(null, "Datos no encontrados");
                limpiar();
            }
            
        }
        
        if (e.getSource() == frm.btnlimpiar ){
            limpiar();
        }
        
    } 
    
    public void limpiar() {
        frm.txtid.setText(null);
        frm.txtcodigo.setText(null);
        frm.txtnombre.setText(null);
        frm.txtprecio.setText(null);
        frm.txtcantidad.setText(null);
    }
}
