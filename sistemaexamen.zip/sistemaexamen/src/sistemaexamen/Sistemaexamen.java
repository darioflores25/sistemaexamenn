/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaexamen;

import controlador.ctrlproducto;
import modelo.consultas_producto;
import modelo.producto;
import vista.frmProducto;
import vista.menu;

/**
 *
 * @author Gustavo
 */
public class Sistemaexamen {

    /**
     * @param args the command line arguments
     */
    public static void main (String[] arg) {
        menu.main(arg);
        
        producto mod = new producto();
        consultas_producto modC = new consultas_producto();
        frmProducto frm = new frmProducto();
        
        ctrlproducto ctrl = new ctrlproducto(mod,modC,frm);
        ctrl.iniciar();
        frm.setVisible(true);
    }
    
}
